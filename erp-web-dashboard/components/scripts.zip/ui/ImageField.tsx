"use client";

import { useRef, useState } from "react";
import { Button } from "@/components/arc/button/button";
import { FileDropzone } from "@/components/arc/file-dropzone/file-dropzone";
import { Muted } from "@/components/ui/Table";

const VIEW = 240;
const OUTPUT = 512;
const QUALITY = 0.82;

export interface ImageFieldProps {
  label: string;
  description?: string;
  /** Data URL that is already cropped and compressed. */
  value: string;
  onChange: (dataUrl: string) => void;
  /** Rejects anything above this before it is read. */
  maxSourceSize?: number;
}

/**
 * Square photo picker: drop a file, then crop it in a fixed frame (drag to pan,
 * slider to zoom) before it is drawn to a 512px canvas and exported as a
 * compressed JPEG data URL. The "Edit" button reopens the same crop stage.
 */
export function ImageField({ label, description, value, onChange, maxSourceSize = 8 * 1024 * 1024 }: ImageFieldProps) {
  const [draft, setDraft] = useState<string | null>(null);
  const [natural, setNatural] = useState({ w: 0, h: 0 });
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [error, setError] = useState<string | null>(null);
  const drag = useRef<{ x: number; y: number; ox: number; oy: number } | null>(null);

  const baseScale = natural.w && natural.h ? Math.max(VIEW / natural.w, VIEW / natural.h) : 1;
  const scale = baseScale * zoom;

  function clamp(next: { x: number; y: number }, factor: number) {
    const maxX = Math.max(0, (natural.w * baseScale * factor - VIEW) / 2);
    const maxY = Math.max(0, (natural.h * baseScale * factor - VIEW) / 2);
    return {
      x: Math.min(maxX, Math.max(-maxX, next.x)),
      y: Math.min(maxY, Math.max(-maxY, next.y)),
    };
  }

  function pick(file: File) {
    if (!file.type.startsWith("image/")) {
      setError("Berkas harus berupa gambar.");
      return;
    }
    if (file.size > maxSourceSize) {
      setError(`Gambar terlalu besar (maks ${Math.round(maxSourceSize / (1024 * 1024))} MB).`);
      return;
    }
    setError(null);
    const reader = new FileReader();
    reader.onload = () => {
      setDraft(typeof reader.result === "string" ? reader.result : null);
      setNatural({ w: 0, h: 0 });
      setZoom(1);
      setOffset({ x: 0, y: 0 });
    };
    reader.readAsDataURL(file);
  }

  function apply() {
    const image = document.createElement("img");
    image.src = draft ?? "";
    image.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = OUTPUT;
      canvas.height = OUTPUT;
      const context = canvas.getContext("2d");
      if (!context) return;
      const sourceSize = VIEW / scale;
      const sx = (natural.w * scale - VIEW) / 2 / scale - offset.x / scale;
      const sy = (natural.h * scale - VIEW) / 2 / scale - offset.y / scale;
      context.drawImage(
        image,
        Math.max(0, sx),
        Math.max(0, sy),
        Math.min(sourceSize, natural.w),
        Math.min(sourceSize, natural.h),
        0,
        0,
        OUTPUT,
        OUTPUT
      );
      onChange(canvas.toDataURL("image/jpeg", QUALITY));
      setDraft(null);
    };
  }

  if (draft) {
    return (
      <div className="crop">
        <span className="crop__label">{label}</span>
        <div
          className="crop__stage"
          onPointerDown={(event) => {
            event.currentTarget.setPointerCapture(event.pointerId);
            drag.current = { x: event.clientX, y: event.clientY, ox: offset.x, oy: offset.y };
          }}
          onPointerMove={(event) => {
            if (!drag.current) return;
            setOffset(
              clamp(
                {
                  x: drag.current.ox + (event.clientX - drag.current.x),
                  y: drag.current.oy + (event.clientY - drag.current.y),
                },
                zoom
              )
            );
          }}
          onPointerUp={() => {
            drag.current = null;
          }}
          onPointerCancel={() => {
            drag.current = null;
          }}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={draft}
            alt="Pratinjau potong"
            onLoad={(event) =>
              setNatural({ w: event.currentTarget.naturalWidth, h: event.currentTarget.naturalHeight })
            }
            style={{
              transform: `translate(-50%, -50%) translate(${offset.x}px, ${offset.y}px) scale(${scale})`,
            }}
          />
          <span className="crop__frame" aria-hidden="true" />
        </div>
        <label className="crop__zoom">
          <span>Zoom</span>
          <input
            type="range"
            min={1}
            max={3}
            step={0.01}
            value={zoom}
            onChange={(event) => {
              const next = Number(event.target.value);
              setZoom(next);
              setOffset((current) => clamp(current, next));
            }}
          />
        </label>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={apply} disabled={!natural.w}>
            Gunakan foto
          </Button>
          <Button size="sm" variant="secondary" onClick={() => setDraft(null)}>
            Batal
          </Button>
        </div>
        <Muted>Seret gambar untuk mengatur posisi. Hasil dipotong 1:1 lalu dikompres ke JPEG 512×512.</Muted>
      </div>
    );
  }

  if (value) {
    return (
      <div className="flex items-center gap-3">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={value} alt={label} width={72} height={72} style={{ objectFit: "cover", borderRadius: 999 }} />
        <div className="flex flex-col gap-2">
          <span className="text-xs">{label} siap dipakai.</span>
          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                setDraft(value);
                setNatural({ w: 0, h: 0 });
                setZoom(1);
                setOffset({ x: 0, y: 0 });
              }}
            >
              Edit
            </Button>
            <Button size="sm" variant="ghost" onClick={() => onChange("")}>
              Hapus
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-2">
      <FileDropzone
        label={label}
        description={description ?? "Gambar akan dipotong 1:1 dan dikompres otomatis."}
        accept="image/png,image/jpeg,image/webp"
        maxFiles={1}
        maxSize={maxSourceSize}
        note="PNG, JPEG, atau WebP. Maksimal 8 MB sebelum dikompres."
        onFilesChange={(files) => {
          const file = files[0];
          if (file) pick(file);
        }}
      />
      {error ? <Muted>{error}</Muted> : null}
    </div>
  );
}
import type { ReactNode } from "react";

interface TableProps {
  head: (string | ReactNode)[];
  rows: ReactNode[][];
  /** Minimum table width so dense columns scroll instead of squashing. */
  minWidth?: number;
  /** Right-align numeric columns by index, e.g. `[1, 2, 3]`. */
  numeric?: number[];
  empty?: string;
  /** Makes rows clickable, e.g. to open a detail panel. */
  onRowClick?: (rowIndex: number) => void;
  /** Highlights the active row when a detail panel is open. */
  selectedRow?: number;
}

export function Table({
  head,
  rows,
  minWidth = 560,
  numeric = [],
  empty = "Belum ada data",
  onRowClick,
  selectedRow,
}: TableProps) {
  if (!rows.length) {
    return (
      <div className="table-empty" role="status">
        {empty}
      </div>
    );
  }

  return (
    <div className="table-shell">
      <div className="table-scroll">
        <table className="data-table" style={{ minWidth }}>
          <thead>
            <tr>
              {head.map((cell, index) => (
                <th key={index} data-num={numeric.includes(index) || undefined}>
                  {cell}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, rowIndex) => (
              <tr
                key={rowIndex}
                data-clickable={onRowClick ? "" : undefined}
                data-selected={selectedRow === rowIndex ? "" : undefined}
                onClick={onRowClick ? () => onRowClick(rowIndex) : undefined}
              >
                {row.map((cell, cellIndex) => (
                  <td key={cellIndex} data-num={numeric.includes(cellIndex) || undefined}>
                    {cell}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function PageHeader({
  title,
  description,
  aside,
}: {
  title: string;
  description: string;
  aside?: ReactNode;
}) {
  return (
    <header className="page-head">
      <div className="page-head__text">
        <h1 className="page-head__title">{title}</h1>
        <p className="page-head__desc">{description}</p>
      </div>
      {aside ? <div className="page-head__aside">{aside}</div> : null}
    </header>
  );
}

export function Muted({ children }: { children: ReactNode }) {
  return <span className="text-xs" style={{ color: "var(--text-muted)" }}>{children}</span>;
}

/** Small label/value pair used inside dense panels. */
export function StatRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="stat-row">
      <span className="stat-row__label">{label}</span>
      <span className="stat-row__value">{value}</span>
    </div>
  );
}
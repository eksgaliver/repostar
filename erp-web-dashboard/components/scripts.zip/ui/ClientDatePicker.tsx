"use client";

import { useEffect, useState } from "react";
import { DatePicker } from "@/components/arc/date-picker/date-picker";
import type { DatePickerProps } from "@/components/arc/date-picker/date-picker";
import { Muted } from "@/components/ui/Table";

/**
 * Arc's DatePicker builds a `new Date()` while rendering, which cacheComponents
 * rejects during prerender. Mounting it after hydration keeps the static shell
 * clean and leaves the interaction untouched.
 */
export function ClientDatePicker(props: DatePickerProps) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return <Muted>{props.label}</Muted>;
  }

  return <DatePicker {...props} />;
}
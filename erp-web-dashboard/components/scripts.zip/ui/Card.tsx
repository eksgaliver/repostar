import type { ReactNode } from "react";
import { Card as ArcCard } from "@/components/arc/card/card";
import type { CardProps } from "@/components/arc/card/card";

export type PanelProps = CardProps & { children?: ReactNode };

/**
 * Arc `Card` prints its children straight after the description with no
 * vertical rhythm, which reads cramped. This wrapper keeps the Arc surface and
 * gives the body consistent spacing. Import this instead of the arc path.
 */
export function Card({ children, className, ...props }: PanelProps) {
  return (
    <ArcCard {...props} className={["ui-card", className].filter(Boolean).join(" ")}>
      {children ? <div className="panel-body">{children}</div> : null}
    </ArcCard>
  );
}

export default Card;